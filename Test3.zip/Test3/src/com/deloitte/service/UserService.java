package com.deloitte.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.bean.User;
import com.deloitte.dao.IUserDao;
import com.deloitte.exception.UserException;

@Transactional
@Service
public class UserService implements IUserService {
	
	@Autowired
	IUserDao uDao;

	@Override
	public Boolean checkName(String name, String password) throws UserException {
		// TODO Auto-generated method stub
		return uDao.checkName(name, password);
	}

	@Override
	public List<User> getUsers() throws UserException {
		// TODO Auto-generated method stub
		return uDao.getUsers();
	}

}
