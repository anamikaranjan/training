package com.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.deloitte.bean.User;
import com.deloitte.exception.UserException;
import com.deloitte.service.IUserService;

@Controller
public class UserController {
	@Autowired
	IUserService uService;
	List<User> ulist;

	@RequestMapping(value = "/login.obj")
	public String redirectToLogin(Model model) {
		// Just Redirect to Login Jsp
		return "loginForm";
	}

	@RequestMapping(value = "/checkLogin.obj")
	public String redirectToAfterLogin(@RequestParam("name") String name, @RequestParam("password") String password,
			Model model) throws UserException {
		Boolean success = uService.checkName(name, password);
		if (success)
			return "successLogin";
		else
			return "errorLogin";

	}

	@RequestMapping(value = "displayUsers.obj")
	public String redirectToDisplayUsers(Model model) throws UserException {
		ulist = uService.getUsers();
		model.addAttribute("elist", ulist);
		return "showAllUsers";
	}

	@RequestMapping(value = "goHome.obj")
	public String redirectToHome() {
		return "index";
	}
}
