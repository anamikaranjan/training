package com.deloitte.dao;

import java.util.List;

import com.deloitte.bean.User;
import com.deloitte.exception.UserException;

public interface IUserDao {

	Boolean checkName(String name, String password) throws UserException;

	List<User> getUsers() throws UserException;

}
