package com.deloitte;
import java.util.*;


public class MovieList {

	public static void main(String[] args) {
		List<Movie> movieList=new ArrayList<>();
		movieList.add(new Movie(1 ,"Star Wars", "05/03/2020", "13:45", "Available"));
		movieList.add(new Movie(2 , "Witcher","30/12/2019", "08:40", "Unavailable"));
		movieList.add(new Movie(3 , "Harry Potter","30/12/2019", "08:40", "Unavailable"));
		movieList.add(new Movie(4 , "Star Trek","30/12/2019", "08:40", "Unavailable"));
		movieList.add(new Movie(5 , "Lord of the Rings","30/12/2019", "08:40", "Unavailable"));
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the movie ID");
		System.out.println("Enter 1 for Star Wars");
		System.out.println("Enter 2 for Witcher");
		System.out.println("Enter 3 for Harry Potter");
		System.out.println("Enter 4 for Star Trek");
		System.out.println("Enter 5 for Lord of the Rings");
		int choice=sc.nextInt();
		MovieChoice object=new MovieChoice();
		System.out.println(object.selectMovie(choice));
	}

	public static Object get(int i) {
		
		return null;
	}

	



}
